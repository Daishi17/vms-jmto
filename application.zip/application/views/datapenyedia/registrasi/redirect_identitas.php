<script>
    setTimeout(function() {
        location.replace('https://e-tender-jmto.kintekindo.net')
    }, 4000);
</script>